#include <stdlib.h>
#include <stdio.h>

int main()
{
	int a, b;
	scanf("%d %d", &a, &b);
	/* 當 a %= b 成立時，表示a除以b的餘數為0，而b除以a的餘數不為0，此時b是a和b的最大公因數，故跳出迴圈。
    同理當 b %= a 成立時，表示b除以a的餘數為0，而a除以b的餘數不為0，此時a是a和b的最大公因數，故跳出迴圈。
	在迴圈中使用&& (and) 運算子是因為只有兩個運算子都為真，整體運算結果才會為真，才會執行後面的printf語句。
	最終，printf("%d\n",a+b); 將a和b的最大公因數輸出。 */
	while((a %= b) && (b %= a));
	printf("%d\n",a+b);
    return 0;
}