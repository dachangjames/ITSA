#include <stdlib.h>  
#include <stdio.h>  

/* 將輸入的矩陣進行轉置，並輸出轉置後的結果。
首先，宣告三個變數 a, b, count 分別代表輸入的矩陣的行數、列數、以及用來分隔數字的空白的計數器。
接下來，使用scanf()讀入矩陣的行數、列數、以及矩陣中的所有數字。
然後宣告一個名為box的陣列，長度為a*b，並將讀入的數字存入box陣列中。
接著使用二重迴圈，外層迴圈遍歷列(y)，內層迴圈遍歷行(x)。
先將count增加1，然後使用printf()輸出矩陣中的數字。
接著判斷count是否為a的倍數，如果不是，在輸出的數字後面加上空白。
每次結束內層迴圈後，換行。最後，程式結束並回傳0。 */
int main()
{  
    int a, b, count = 0; // 若這裡忘記將變數count先初始化數值為0的話，可能會導致輸出時，無法預測用來分隔數字的空白會出現在什麼位置
    scanf("%d %d", &a, &b);
    int box[a*b];
    for(int i = 0; i < (a * b); i++)
	{
    	scanf("%d", &box[i]);
	}
	for(int y = 0; y < b; y++)
	{
		for(int x = 0; x < a; x++)
		{
			count++;
			printf("%d", box[x * b + y]);
			if(count % a != 0)
			{
				printf(" ");
			}
		}
		printf("\n");
	}
    return 0;
}