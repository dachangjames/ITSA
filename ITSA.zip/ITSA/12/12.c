#include <stdio.h>
#include <stdlib.h>

/* 首先，定義遞迴函數f(int n)，該函數接收一個整數n作為參數。
然後在函數內部，首先判斷當n等於1或0時，直接返回n+1。
如果n不等於1或0，則遞迴地調用該函數，並將n-1和n/2作為參數傳遞。
函數最終返回兩次遞迴調用的結果之和。 */

int f(int);

int f(int n)
{
	if(n == 1 || n == 0)
	{
		return n + 1;
	}
	else
	{
		return (f(n - 1) + f(n / 2));
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	printf("%d\n", f(n));
    return 0;
}