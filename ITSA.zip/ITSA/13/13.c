#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct card
{
    char suit;
    int num;
};

int cmp(const void* a, const void* b)
{
    struct card* c1 = (struct card*)a;
    struct card* c2 = (struct card*)b;

    if (c1->suit != c2->suit)
    {
        // 判斷兩張牌的花色，並根據 黑桃 > 紅心 > 方塊 > 梅花的順序來判斷兩張牌的大小。
        if (c1->suit == 'S') return -1;
        /* 如果c1的花色是'H'(紅心)，那麼返回1(c1大於c2)，如果c2的花色是'S'(黑桃)，否則返回-1(c1小於c2)。 */
        if (c1->suit == 'H') return c2->suit == 'S' ? 1 : -1;
        /* 如果c1的花色是'D'(方塊)，那麼返回-1(c1小於c2)，如果c2的花色是'C'(梅花)，否則返回1(c1大於c2)。 */
        if (c1->suit == 'D') return c2->suit == 'C' ? -1 : 1;
        if (c1->suit == 'C') return 1;
    }
    else
    {
        // 花色相同時，比較數字
        /* 效果相當於
        if (card1 < card2) return -1;
        if (card1 > card2) return 1; */
        return c1->num - c2->num;
    }
}

int main()
{
    int n, i, j;
    scanf("%d", &n);
    getchar();

    for (i = 0; i < n; i++)
    {
        char input[100];
        fgets(input, sizeof(input), stdin);
        int len = strlen(input);
        struct card cards[20];
        int cards_count = 0;
        /* strtok(input, " ")是一個函數，用於在字串中分割字串。它會在輸入的字串中（input）查找第一個以空格（" "）分隔的字串，
        並將其作為第一個返回的字串返回。之後，如果再次調用strtok（input，" "），則會在原始字串的下一部分繼續查找下一個以空格分隔的字串。
        這裡的char* token = strtok(input, " ");是將input字串以空格分割，並且將第一個空格前的字串賦值給token。 */
        char* token = strtok(input, " ");
        while (token != NULL)
        {
            cards[cards_count].suit = token[0];
            /* 因為token是字串，而num是整數，所以要先將token轉成整數。
            這一行程式碼是將 token + 1 (token 是一個字串，+ 1 是將指標移到第二個字元)轉換為整數 (也就是說，是將 token(字串) 轉換為整數)
            並存入 cards[cards_count].num 這個變數裡，atoi 是一個 C 語言內建函數，用來將字串轉換為整數。 */
            cards[cards_count].num = atoi(token + 1);
            cards_count++;
            token = strtok(NULL, " ");
        }

        /* 快速排序。(cards是要排序的數組名；cards_count是數組中元素的個數；
        sizeof(struct card)表示每個元素的大小；
        cmp是一個比較函數，用來指定如何排序。) */
        qsort(cards, cards_count, sizeof(struct card), cmp);

        for (j = 0; j < cards_count; j++)
        {
            printf("%c%d ", cards[j].suit, cards[j].num);
        }
        printf("\n");
    }
    printf("\n");
    return 0;
}