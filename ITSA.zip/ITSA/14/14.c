#include <stdio.h>
#include <string.h>

int main()
{
    int n, i, j;
    char num[10];
    scanf("%d", &n);
    sprintf(num, "%d", n); //把整數轉成字串存入num陣列中
    int len = strlen(num); //獲取字串長度
    for (i = 0, j = len - 1; i < len / 2; i++, j--)
    {
        if (num[i] != num[j])
        {
            printf("NO\n");
            return 0;
        }
    }
    printf("YES\n");
    return 0;
}
