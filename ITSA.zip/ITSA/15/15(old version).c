#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    char input[10000], *save, *w = "aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ";
    int wordsNum = 0;
    char *temp;
    int wF[52] = {0};

    fgets(input, sizeof(input), stdin);
    temp = strtok(input, " ");
    while (temp != NULL)
    {
        wordsNum++;
        for (int j = 0; j < strlen(temp); j++)
        {
            if (temp[j] >= 'a' && temp[j] <= 'z')
                wF[temp[j] - 'a']++;
            else if (temp[j] >= 'A' && temp[j] <= 'Z')
                wF[temp[j] - 'A' + 26]++;
        }
        temp = strtok(NULL, " ");
    }
    printf("%d\n", wordsNum);
    for (int k = 0; k < 52; k++)
    {
        if (wF[k] != 0)
            printf("%c : %d\n", w[k], wF[k]);
    }
    return 0;
}
