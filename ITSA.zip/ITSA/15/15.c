/* 此程式首先使用 fgets() 將輸入的字串存入 input 陣列中，接著利用 isalpha() 函數和迴圈來計算單字數量，
   再利用 tolower() 函數和迴圈來計算每個字母的出現次數，最後輸出結果。 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* <ctype.h>是一個C語言的標頭檔，它包含了一系列的字元類型檢查函數。在這個題目中，我們可以使用其中的函數isalpha()來檢查
輸入的字元是否為英文字母，以便過濾出所有的單字。而使用tolower()來將所有的英文字母轉成小寫，以便計算字母出現頻率時不用考慮大小寫的影響。 */

int main()
{
    int word_count = 0;
    int letter_count[26] = {0}; // 用來存放每個字母的出現次數
    char input[100];
    memset(input, '\0', sizeof(input)); // 字符'\0'在C中的意義是「空字元」或「字串的結束標示」，本質上就是NULL，ASCII碼為0。
    /* 讀取使用者在標準輸入(stdin)中輸入的字串，並將其存入input陣列中。參數input為存放使用者輸入字串的陣列，100為該陣列的大小，stdin為標準輸入。
    此函數會一直讀取至標準輸入結束或陣列大小為100為止。 */
    fgets(input, 100, stdin);
    int input_len = strlen(input);
    // 用來計算單字數量
    for(int i = 0; i < input_len; i++)
    {
        if(isalpha(input[i]) && (input[i-1] == ' ' || input[i-1] == '.' || input[i-1] == ',' || i == 0))
        {
            word_count++;
        }
    }
    // 用來計算每個字母的出現次數
    for(int i = 0; i < input_len; i++)
    {
        if(isalpha(input[i]))
        {
            /* letter_count是一個長度為26的整數陣列，用來存放每個小寫字母的出現次數。
            tolower(input[i])將輸入的字符轉換為小寫字母。'a'是字元常數，代表字元'a'。
            所以letter_count[tolower(input[i]) - 'a']++就是將對應的小寫字母出現次數+1。
            例如: 輸入字元為'A'，tolower(input[i])將其轉換為'a'，letter_count['a'-'a']++ 就是將letter_count[0]++。 */
            letter_count[tolower(input[i]) - 'a']++;
        }
    }
    printf("%d\n", word_count);
    for(int i = 0; i < 26; i++)
    {
        if(letter_count[i] > 0)
        {
            printf("%c : %d\n", i+'a', letter_count[i]);
        }
    }
    return 0;
}
