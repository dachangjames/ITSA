#include <stdio.h>
#include <string.h>

int main()
{
    char str1[130], str2[514];
    int count = 0;
    scanf("%s %s", str1, str2); // 讀取兩個字串
    char *p = strstr(str2, str1); // 使用strstr()函數在str2中找到str1第一次出現的位置
    while (p != NULL)
    {
    count++;
    p = strstr(p + 1, str1); // 更新p的值並繼續在剩下的部分中找下一個
    }
    printf("%d\n", count);
    return 0;
}