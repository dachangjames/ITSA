/* C 語言可以使用 string.h String Token (strtok) 去解決
我們來看 strtok 函式原型 
char* strtok( char* str, const char* delim );
引數傳要切割的字串 str、切割的關鍵字元 delim

回傳的是字元指標，就是位於切割字元之間的字串
如果拿到 NULL 就代表已經沒了

但是，如果想再搜尋同一句話的下一個切割字元之間字串，str 就傳 NULL 即可

通常我會搭配 while 迴圈去完成

這題要先把所有字串轉為小寫
第一次做 strtok 的時候要 str 引數傳需要被切割的字串
第二次以後 str 引數直接傳 NULL
直到回傳值為 NULL 跳出迴圈

while 迴圈裡，需要搜尋這個字串是否存在

搭配 strcmp 去完成

不存在則於迴圈的最後 strcpy 進去

最後再列出所有字串 */

#include<stdio.h>  
#include<string.h>  
#include<ctype.h>  
int main() {  
    char enter[10000];  
    fgets(enter, 9999, stdin);  
    int len = strlen(enter);  
    for (int i = 0 ; i < len; i++) {  
        enter[i] = tolower(enter[i]);  
    }  
    char ans[1000][1000];  
    int nowAns = 0;  
    char *pch = strtok(enter, " \r\n");  // 垃圾judge (見註1)
    while(pch != NULL) {  
        int judge = 1;  
        for (int i = 0; i < nowAns; i++) {  
            if (strcmp(ans[i], pch) == 0) {  
                judge = 0;  
                break;  
            }  
        }  
        if (judge) {  
            strcpy(ans[nowAns], pch);  
            nowAns++;  
        }  
        pch = strtok(NULL, " \r\n");  // 垃圾judge (見註1)
    }  
    for (int i = 0; i < nowAns; i++) {  
        if(i)  
            printf(" ");  
        printf("%s", ans[i]); 
    }  
    printf("\n");  
    return 0;  
}

/* 註1： 以下為解釋為什麼是放\r\n而非\n
理當來說換行為 \n
但是Windows的換行為 \r\n
因此我覺得測試資料可能有些是 Windows 手動產生
真謝謝你喔 垃圾judge浪費老子時間一直試
 */