#include <stdio.h>

int main()
{
    // 初始化變數為0
    int miles = 0;
    double kilometers = 0.0;
    // 輸入英哩數
    scanf("%d", &miles);
    // 1英哩 = 1.6公里
    kilometers = miles * 1.6;
    printf("%.1f\n", kilometers); // 操你媽的垃圾judge，真他媽謝謝你為了一個換行(\n)浪費老子的時間
    return 0;
}