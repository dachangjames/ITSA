#include <stdio.h>  
#include <stdlib.h>
#include <math.h>  
  
int main()
{  
    int x[2];
    // 這個輸入方式相當於「輸入1 輸入2」，用空白隔開即可，效果相當於「輸入1 Enter鍵 輸入2」
    for(int i = 0; i < 2; i++)
    {  
        scanf("%d", &x[i]);  
    }
    /* 想法：利用畢氏定理，因為已知圓的半徑是200 / 2 = 100，所以如果 點的x座標(也就是三角形的底邊)平方 + 點的y座標(也就是三角形的高邊)平方
       會小於或等於圓的半徑100(也就是三角形的斜邊)平方的話，那代表這個點在圓內。否則，這個點在圓外。 */
    if(pow(x[0], 2) + pow(x[1], 2) <= pow(100, 2))
    {  
        printf("inside\n");  
    }  
    else
    {  
        printf("outside\n");  
    }
    return 0;
}  