/* 想法：比較簡單區隔月份&日期的方法之一是將月份 x 100 的加權倍率之後，加上日期，就形成了一個數字，
這種數字能確保當月份&日期越後面時，該數字會隨之變大。由於judge不可能會放非正常月份&日期的測資(有放的話題目一定會指明)，因此不用考慮這部分的問題。 */

#include <stdio.h>

int main()
{
    int month = 0, day = 0, score = 0;
    scanf("%d %d", &month, &day);
    score = (month * 100) + day;

    if(score >= 121 && score <= 218)
    {
        printf("Aquarius\n"); // 水瓶
    }
    else if(score >= 219 && score <= 320)
    {
        printf("Pisces\n"); // 雙魚
    }
    else if(score >= 321 && score <= 420)
    {
        printf("Aries\n"); // 牡羊
    }
    else if(score >= 421 && score <= 521)
    {
        printf("Taurus\n"); // 金牛
    }
    else if(score >= 522 && score <= 621)
    {
        printf("Gemini\n"); // 雙子
    }
    else if(score >= 622 && score <= 722)
    {
        printf("Cancer\n"); // 巨蟹
    }
    else if(score >= 723 && score <= 823)
    {
        printf("Leo\n"); // 獅子
    }
    else if(score >= 824 && score <= 923)
    {
        printf("Virgo\n"); // 處女
    }
    else if(score >= 924 && score <= 1023)
    {
        printf("Libra\n"); // 天秤
    }
    else if(score >= 1024 && score <= 1122)
    {
        printf("Scorpio\n"); // 天蠍
    }
    else if(score >= 1123 && score <= 1221)
    {
        printf("Sagittarius\n"); // 射手
    }
    else if( (score >= 1222 && score <= 1231) ||  (score >= 101 && score <= 120) )
    {
        printf("Capricorn\n"); // 魔羯
    }

    return 0;
}