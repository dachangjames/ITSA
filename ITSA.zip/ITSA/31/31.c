#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int count = 0, max_num = 0;
    char input[100];
    memset(input, NULL, sizeof(input));
    int numbers[1000];
    memset(numbers, NULL, sizeof(numbers));
    /* 在C語言中可以使用fgets()或scanf()函數來讀取一行字串，再使用sscanf()函數將讀入的字串中的數字分別存入陣列中。 */
    int a = 0, flag = 0;
    int num_count = 0;
    int number;
    while(fgets(input, 100, stdin) != NULL)
    {
        char *p = strtok(input, " ");
        a = 0;
        num_count = 0;
        flag = 0; // 設定flag為0
        memset(numbers, NULL, sizeof(numbers)); // 清空numbers陣列

        while (p != NULL)
        {
            sscanf(p, "%d", &number);
            numbers[a] = number;
            a++;
            num_count++;
            p = strtok(NULL, " ");
        }
        /* 執行上述將會把輸入的一行字串用空白將每個數字互相分隔開，並存入陣列numbers裡。
        若數字的數量不足10個，則陣列numbers所剩下未存入的index其值將為NULL。 */

        for(int i = 0; i < num_count; i++)
        {
            count = 0;
            // 在所有數字中尋找，如果某數字等於numbers[i]的話，count就加1，完成這個for迴圈之後，count的值就是numbers[i]在所有數字中有幾個
            for(int j = 0; j < num_count; j++)
            {
                if(numbers[i] == numbers[j])
                {
                    count++;
                }
            }
            // 如果count的值(也就是numbers[i]在所有數字中的個數)超過「所有數字的總個數 / 2」的話，那numbers[i]該數就是過半元素
            if(count > num_count / 2)
            {
                max_num = numbers[i];
                flag = 1;
                break;
            }
        }

        if(flag == 0)
        {
            printf("NO\n");
        }
        else
        {
            printf("%d\n", max_num);
        }
    }

    return 0;

}