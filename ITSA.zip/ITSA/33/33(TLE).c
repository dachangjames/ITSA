#include <stdio.h>

int main()
{
    int num, count = 0;
    float sum = 0, average;
    
    /* scanf("%d", &num)會讀取一個整數，並將其存入變數num中。如果讀取成功，會回傳1，讀取失敗則回傳0。
    所以 while(scanf("%d", &num) == 1) 是用來判斷讀取是否成功。 */
    while(scanf("%d", &num) == 1)
    {
        count++;
        sum += num;
        while(getchar() != '\n')
        {
            scanf("%d", &num);
            count++;
            sum += num;
        }
        average = (float)sum / count;
        printf("Size: %d\nAverage: %.3f\n", count, average);
        count = 0;
        sum = 0;
    }
    
    return 0;
}
