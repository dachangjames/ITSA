/* 舊版會造成TLE的原因是，scanf() 會在讀取到空白字元後停止，而 getchar() 會讀取輸入緩衝區中所有字元，造成程式運行時間過長。
而在上面程式碼中，在每次計算完後使用 while(getchar() != '\n') 來清除輸入緩衝區，可以減少讀取過多字元的時間。 */

// 註：手動輸入EOF的另一個方法是直接加上 ctrl + D。

#include <stdio.h>

int main()
{
    int num, count = 0;
    float sum = 0, average;
    
    /* scanf("%d", &num)會讀取一個整數，並將其存入變數num中。如果讀取成功，會回傳1，讀取失敗則回傳0。
    所以 while(scanf("%d", &num) == 1) 是用來判斷讀取是否成功。 */
    while(scanf("%d", &num) == 1)
    {
        count++;
        sum += num;
        while(scanf("%d", &num) == 1)
        {
            count++;
            sum += num;
        }
        average = (float)sum / count;
        printf("Size: %d\nAverage: %.3f\n", count, average);
        count = 0;
        sum = 0;
        // 清除輸入緩衝區
        while(getchar() != '\n');
    }
    return 0;
}
