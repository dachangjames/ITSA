#include <stdio.h>

int main()
{
    int height = 0, gender = 0;
    double standard_weight = 0;
    // EOF的手動打法：在最後一行已輸入結束後，按Enter，接著按ctrl + z，接著再按一次Enter即可。
    // 補充：另一種打法是直接在輸入完成後加上 ctrl + D 即可。
    while(scanf("%d %d", &height, &gender) != EOF)
    {
        // 判斷為男性(gender = 1)或女性(gender = 2)
        if(gender == 1)
        {
            standard_weight = (height - 80) * 0.7;
            /* %.1f是printf()中的格式化字符，它表示將輸出的浮點數（如standard_weight）保留小數點後一位，並四捨五入。
            例如，如果standard_weight的值為123.45678，則輸出結果為123.5。 */
            printf("%.1f\n", standard_weight);
        }
        else if(gender == 2)
        {
            standard_weight = (height - 70) * 0.6;
            printf("%.1f\n", standard_weight);
        }
    }

    return 0;
}