/* 想法：因為題目要求花費最低且不超過總預算，所以我們可以先將所有禮物的價格由小到大排列，並依據員工數量，從價格最低者開始購買，
直到買的禮物數量恰等於員工數為止。而此時的價格加總就是總花費，將其與總預算比較，若小於或等於總預算則代表可以負擔，此時便輸出總花費；
否則代表不可能負擔，此時便輸出Impossible(不可能)。舉例：預算T = 200，員工數m = 3，禮物價目表為 55 60 150 75 90 62；
先由小到大排列成 55 60 62 75 90 150，有3個員工，代表要買前3便宜的禮物，因此總花費為55 + 60 + 62 = 177，小於總預算200，因此輸出(總花費)177。 */

#include <stdio.h>

int main()
{
    int n = 0;

    scanf("%d", &n); // 首先輸入n，代表接下來有n筆測試資料

    for(int i = 0; i < n; i++)
    {
        int T = 0, m = 0, k = 0;
        int price[100] = {0};
        int temp = 0, sum = 0;

        scanf("%d %d %d", &T, &m, &k); // 輸入 總預算，員工數(禮物數量)，有k件物品可供選購
        for(int j = 0; j < k; j++) // 輸入(第1 ~ k種)物品的售價
        {
            scanf("%d", &price[j]);
        }

        // 將物品售價由小到大排列
        for(int i = 0; i < k; i++)
        {
            for(int j = i; j < k; j++)
            {
                if(price[j] < price[i])
                {
                    temp = price[j];
                    price[j] = price[i];
                    price[i] = temp;
                }
            }
        }

        // 計算總花費
        for(int i = 0; i < m; i++)
        {
            sum += price[i];
        }

        // 判斷總花費是否超出預算
        if(sum <= T)
        {
            printf("%d\n", sum);
        }
        else
        {
            printf("Impossible\n");
        }

    }

    return 0;
}
