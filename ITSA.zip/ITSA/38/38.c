#include <stdio.h>

int main()
{
    int degrees = 0;
    scanf("%d", &degrees);

    double summer_money = 0.0;
    double non_summer_money = 0.0;

    // Calculate money for summer months
    if(degrees <= 120)
    {
        summer_money = degrees * 2.10;
    }
    else if(degrees >= 121 && degrees <= 330)
    {
        summer_money = 120 * 2.10 + (degrees - 120) * 3.02;
    }
    else if(degrees >= 331 && degrees <= 500)
    {
        summer_money = 120 * 2.10 + 210 * 3.02 + (degrees - 330) * 4.39;
    }
    else if(degrees >= 501 && degrees <= 700)
    {
        summer_money = 120 * 2.10 + 210 * 3.02 + 170 * 4.39 + (degrees - 500) * 4.97;
    }
    else if(degrees >= 701)
    {
        summer_money = 120 * 2.10 + 210 * 3.02 + 170 * 4.39 + 200 * 4.97 + (degrees - 700) * 5.63;
    }

    // Calculate money for non-summer months
    if(degrees <= 120)
    {
        non_summer_money = degrees * 2.10;
    }
    else if(degrees >= 121 && degrees <= 330)
    {
        non_summer_money = 120 * 2.10 + (degrees - 120) * 2.68;
    }
    else if(degrees >= 331 && degrees <= 500)
    {
        non_summer_money = 120 * 2.10 + 210 * 2.68 + (degrees - 330) * 3.61;
    }
    else if(degrees >= 501 && degrees <= 700)
    {
        non_summer_money = 120 * 2.10 + 210 * 2.68 + 170 * 3.61 + (degrees - 500) * 4.01;
    }
    else if(degrees >= 701)
    {
        non_summer_money = 120 * 2.10 + 210 * 2.68 + 170 * 3.61 + 200 * 4.01 + (degrees - 700) * 4.50;
    }

    printf("Summer months:%.2f\n", summer_money);
    printf("Non-Summer months:%.2f\n", non_summer_money);

    return 0;
}