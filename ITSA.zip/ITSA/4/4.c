#include <stdio.h>  
#include <stdlib.h>

int main()
{  
    int t[4];  
    int min;  
    int count, total;  
    for(int i = 0; i < 4; i++)
    {  
        scanf("%d", &t[i]);  
    }  
    min = (t[2] * 60 + t[3]) - (t[0] * 60 + t[1]);
    // count的意義是有多少個半小時
    count = min / 30;
    if(count <= 4) // 停車2小時以內
    {  
        total = count * 30;  
    }  
    else if(count <= 8) // 停車超過2小時，但未滿4小時
    {  
        total = 120 + (count - 4) * 40;  
    }  
    else // 停車超過4小時
    {
        // (2小時 / 30分鐘) * 30元 + [(4小時 - 2小時) / 30分鐘] * 40元 = 280元
        total = 280 + (count - 8) * 60;  
    } 
    printf("%d\n", total);
    return 0;
}