#include <stdlib.h>  
#include <stdio.h>  
#include <math.h>  
  
int main()
{  
    int x;  
    scanf("%d",&x);  
    // 負數的特別規則：2的補數(two’s complement)，就是將位元反置後再加一。
    if(x < 0)
    {  
        x += 256;  
    }  
    int c[8];
    // 十進位轉二進位的方法：把十進位數字的 個位數 * 1 + 十位數 * 2 + 百位數 * 4 + 千位數 * 8 + ... 以此類推。
    for(int i = 7; i >= 0; i--)
    {  
        c[i] = x / pow(2,i);  
        x %= (int)pow(2,i);  
        printf("%d",c[i]);  
    }  
    printf("\n");  
    return 0;
} 