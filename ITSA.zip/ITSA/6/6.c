#include <stdlib.h>
#include <stdio.h>
  
int main()
{
    int x;
    // 輸入x作為月份  
    scanf("%d", &x);
    // 直接用if-else會太過冗長，所以改用switch-case的方式
    switch(x)
    {
        // 3 ~ 5月：春天
        case 3:
        case 4:
        case 5:
            printf("Spring\n");
            break;
        // 6 ~ 8月：夏天
        case 6:
        case 7:
        case 8:
            printf("Summer\n");
            break;
        // 9 ~ 11月：秋天
        case 9:
        case 10:
        case 11:
            printf("Autumn\n");
            break;
        // 12 ~ 2月：冬天
        case 12:
        case 1:
        case 2:
            printf("Winter\n");
            break;
    }
    return 0;
}