#include <stdio.h>
#include <stdlib.h>  
  
int main()
{
    int n;
    int a, b, c, d;
    char op;
    // 第一列輸入一個正整數n
    scanf("%d",&n);
    // 其後有n列，每一列代表一個想要做運算的虛數
    for(int i = 0; i < n; i++)
    {
        scanf(" %c%d%d%d%d",&op,&a,&b,&c,&d); // op是以字元形式儲存的運算元 
        // 對op用if-else太過冗長，所以改用switch-case
        switch(op)
        {
            /* 虛數的四則運算： 
               +：實部與實部相加，虛部與虛部相加
               -：實部與實部相減，虛部與虛部相減
               *：可以把它想像成兩個二元(x、y)一次式的相乘運算，實部的意義就是x，虛部的意義就是y*/
            case '+':  
                printf("%d %d\n", a + c, b + d);  
                break;  
            case '-':  
                printf("%d %d\n", a - c, b - d);  
                break;
            case '*':  
                printf("%d %d\n", a * c - b * d, b * c + a * d);  
                break;  
        }  
    }
    return 0;
} 