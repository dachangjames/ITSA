#include <stdlib.h>  
#include <stdio.h>  
  
int main()
{  
    int n, i;
    // 輸入一個整數n，作為欲判斷的數。
    scanf("%d",&n);
    /* 首先，定義一個變數i初始值為2,在迴圈中使用i從2開始檢查每一個數字，判斷n是否能被i整除。
    如果n能被i整除，那麼這個數字不是質數，迴圈就結束。
    反之，如果i一直循環到n-1而沒有被整除，那麼這個數字就是質數，輸出"YES"。
    如果i在循環中被整除，那麼這個數字不是質數，輸出"NO"。 */
    for(i = 2; i < n; i++)
    {
        if(n % i == 0)
        {
            break;
        }
    }
    if(i == n)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
    return 0;
}  