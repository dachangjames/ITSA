#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, sum = 0;
    // 輸入一整數n
    scanf("%d", &n);
    // 使用迴圈從1到n，檢查每一個數字是否是3的倍數，如果是，就將它加入到sum中。
    // 意義是計算出1到n之間可被3整除的數值之總和
    for(int i = 1; i <= n;i++)
    {
        if(i % 3 == 0)
        {
            sum += i;
        }
    }
    // 輸出結果
    printf("%d\n", sum);
    return 0;
}